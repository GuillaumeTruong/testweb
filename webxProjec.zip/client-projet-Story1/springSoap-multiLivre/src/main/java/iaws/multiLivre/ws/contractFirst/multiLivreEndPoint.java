package iaws.multiLivre.ws.contractFirst;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.Namespace;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.server.endpoint.annotation.XPathParam;
import org.w3c.dom.Element;

import iaws.multiLivre.ws.generatedClasses.AuteurType;
import iaws.multiLivre.ws.generatedClasses.BibliothequeType;
import iaws.multiLivre.ws.generatedClasses.ResponseType;
import iaws.multiLivre.ws.generatedClasses.ResultType;
import iaws.multiLivre.ws.interfaceClasses.MultiLivreService;

@Endpoint
public class multiLivreEndPoint {

	private MultiLivreService multiLivreService;
	private static final String NAMESPACE_URI = "https://example.com/webx/multi-livre";

	
	//the multiLivreService business service is injected into this endpoint.
	@Autowired
	public multiLivreEndPoint(MultiLivreService multiLivreService) {
		this.multiLivreService = multiLivreService;
	}

	//Nom de l'élément racine
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "ReleveNotesRequest") 
	@Namespace(prefix = "rn", uri = NAMESPACE_URI) 
	// espace de nom pour les expressions XPath ci-dessous
	@ResponsePayload
	public Element handleMultiLivreRequest(@XPathParam("/rn:ReleveNotesRequest/rn:annee_scolaire/text()") String doi,
			@XPathParam("/rn:ReleveNotesRequest/rn:niveau/text()") String adresse) throws Exception {

		// Parse le XML de ReleveNotesRequest pour extraire les informations de
		// l'année scolaire, du niveau et du semestre et créer les objets ad-hoc :
		String doiC = doi;
		String adresseC = adresse;

		// Invoque le service "releveNoteService" pour récupérer les objets recherchés :
		ResponseType evals = multiLivreService.findAllResultTypesForDoiAndAdresse(doiC, adresseC);

		// Transforme en élément XML ad-hoc pour le retour 
		Element elt = XmlHelper.getRootElementFromFileInClasspath("ResponseType.xml");
		return elt;
	}

}