package iaws.multiLivre.ws.impInterface;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;

import iaws.multiLivre.ws.generatedClasses.AuteurType;
import iaws.multiLivre.ws.generatedClasses.BibliothequeType;
import iaws.multiLivre.ws.generatedClasses.ResponseType;
import iaws.multiLivre.ws.generatedClasses.ResultType;
import iaws.multiLivre.ws.interfaceClasses.MultiLivreService;
import scenarioUtilisation.InformationLivre;
import scenarioUtilisation.Isbn2ppnClass;
import scenarioUtilisation.PpnLibrary;
import scenarioUtilisation.UserInformation;
import webx.client_projet_Story1.UserStory1a;
import webx.client_projet_Story1.UserStory1b;
import webx.client_projet_Story1.UserStory1c;
import webx.client_projet_Story1.UserStory1d;
import webx.client_projet_Story1.UserStory1e;



public class ImplMultiLivreService implements MultiLivreService {

	/**
	 * Retourne tous les le resultat de la requête
	 *
	 * @param doi
	 * @param adresse
	 * @return le resultType contenant le titre du document, les auteurs et les
	 *         bibliothèques
	 * @throws JSONException 
	 * @throws UnsupportedEncodingException 
	 */
	public ResponseType findAllResultTypesForDoiAndAdresse(String doi, String adresse) throws UnsupportedEncodingException, JSONException {
		return createResult(doi, adresse);
	}
	
	
	

	private ResponseType createResult(String doi, String adresse) throws UnsupportedEncodingException, JSONException {

		ResponseType result = new ResponseType();


		// Ajout des auteurs
		InformationLivre researchBook = new InformationLivre();
		// researchBook =
		// UserStory1a.recupererInfoDocument("10.1007/978-3-662-07964-5");
		researchBook = UserStory1a.recupererInfoDocument(doi);

		List<AuteurType> auteurList = new ArrayList<AuteurType>();
		for (int i = 0; i < researchBook.getListAuteur().size(); i++) {
			auteurList.add(new AuteurType(researchBook.getListAuteur().get(i).getGiven(),
					researchBook.getListAuteur().get(i).getFamily()));
		}

		// Récupérer les ppn de chaque adresse si l'isbn existe bien sûr
		Isbn2ppnClass isbnPpnInfo = new Isbn2ppnClass();
		isbnPpnInfo = UserStory1b.recupererIdentifiantPPN(researchBook.getISBN(), researchBook);

		// Récupérer liste Bus
		List<PpnLibrary> listLibraryParPpn = new ArrayList<PpnLibrary>();
		UserStory1c.recupererLIstBUs(isbnPpnInfo.getResult().get(0), listLibraryParPpn);

		// Récupérer les informations du user
		UserInformation user = new UserInformation();
		// user =
		// UserStory1d.recupererCoordonneeGeographiqueAvecAdressePostale("10 Rue
		// de la Forge, Bondoufle", user);
		user = UserStory1d.recupererCoordonneeGeographiqueAvecAdressePostale(adresse, user);

		// Récupérer les distances dans l'ordre
		List<Float> distanceList = new ArrayList<Float>();
		distanceList = UserStory1e.recupererDistanceVolOiseau(user, listLibraryParPpn.get(0).getListLibrary());

		// Ajout les bibliothèques
		List<BibliothequeType> bibliotheque = new ArrayList<BibliothequeType>();
		for (int i = 0; i < distanceList.size(); i++)
			bibliotheque.add(new BibliothequeType(listLibraryParPpn.get(0).getListLibrary().get(i).getShortname(),
					distanceList.get(i)));

		// Remplir les données
		result.setResult(new ResultType(researchBook.getTitle(), auteurList, bibliotheque));

		// Remplir ErrorType
		// result.setError(new ErrorType("ok", 200));
		
		return result;
	}

}
